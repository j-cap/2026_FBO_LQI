# DA-FBO paper draft v1

This folder contains the first LaTeX iteration for the proposed paper
**Dynamics-Aware Federated Bayesian Optimization for Safe Controller Calibration in Heterogeneous Systems**.

Files:
- `main.tex` -- IEEE-style two-column draft.
- `references.bib` -- literature used in the Introduction and Methods.
- `DA_FBO_paper_draft_v1.pdf` -- compiled draft.

Important scope note:
- The working title uses "Safe", but the draft explicitly recommends changing this to "Safety-Aware" or "Risk-Aware" unless a formal guarantee is added.
- Full-scale Phase 1B and the actual DA-FBO optimization experiments are still placeholders.
- The proposed methodological target is dynamics-aware federated Thompson sampling using uncertainty-aware identified-model distances to gate peer surrogate transfer, plus target-local uncertainty-based candidate screening.
